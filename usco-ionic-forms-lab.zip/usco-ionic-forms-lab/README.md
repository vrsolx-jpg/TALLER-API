# USCO Ionic Forms Lab + API REST

Aplicación académica con Ionic 8 y Angular 18. Incluye formulario, validación de campos, consumo HTTP con `HttpClient`, servicio centralizado `ApiService` y un backend REST ejecutable sin dependencias adicionales de Node.

## Requisitos
- Node.js 18 o superior
- npm 9 o superior

## Ejecutar frontend y API

Abre dos terminales en la carpeta del proyecto.

**Terminal 1 — API backend**
```bash
npm run api
```
La API queda escuchando en `http://localhost:3000`. Prueba su estado en `http://localhost:3000/api/health`.

**Terminal 2 — Ionic/Angular**
```bash
npm install
npm start
```
Abre `http://localhost:8100`.

Para compilar Angular:
```bash
npm run build
```

## Endpoints

| Método | Ruta | Descripción |
|---|---|---|
| `GET` | `/api/health` | Estado de la API |
| `GET` | `/api/requests` | Lista de solicitudes guardadas |
| `POST` | `/api/requests` | Valida y guarda una solicitud |

Ejemplo del cuerpo de `POST /api/requests`:
```json
{
  "fullName": "Daniel Gómez Perdomo",
  "serviceType": "academic",
  "smsNotifications": true,
  "acceptTerms": true
}
```

El servidor valida los campos y guarda los registros en `server/db.json`. Esta persistencia en archivo es apropiada para el laboratorio local; no sustituye una base de datos de producción.

## Cómo está integrada la guía HTTP

- `src/app/app.config.ts`: registra `provideHttpClient()` globalmente.
- `src/app/services/api.service.ts`: encapsula las llamadas `GET` y `POST` usando `HttpClient` y `Observable`.
- `src/app/home/home.page.ts`: consume el servicio, muestra errores y actualiza el estado de la interfaz.
- `src/environments/environment.ts`: configura la URL base de la API.
- `server/api.mjs`: backend REST de ejemplo funcional.
- `server/db.json`: almacenamiento local de solicitudes.

## Uso en teléfono físico / Capacitor

En `src/environments/environment.ts`, cambia `localhost` por la IP LAN del computador que ejecuta la API, por ejemplo:
```ts
apiUrl: 'http://192.168.1.25:3000/api'
```
Usa la IP real de tu equipo y asegúrate de que el teléfono esté en la misma red. El firewall debe permitir conexiones al puerto 3000. Para producción móvil, publica el backend en HTTPS. CORS está abierto para facilitar el laboratorio local; limita los orígenes permitidos antes de desplegar en producción.

La guía original menciona el plugin HTTP nativo de Capacitor como alternativa si persisten problemas CORS en la WebView. Esta implementación utiliza `HttpClient` estándar y no instala ese plugin porque no es necesario para la prueba web local.

## Estructura principal

```text
src/
  app/
    app.config.ts
    app.routes.ts
    home/
      home.page.ts
      home.page.html
      home.page.scss
    models/
      booking-request.model.ts
    services/
      api.service.ts
      feedback.service.ts
  environments/
    environment.ts
server/
  api.mjs
  db.json
```
