import http from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const PORT = Number(process.env.API_PORT || 3000);
const DB_PATH = path.join(path.dirname(fileURLToPath(import.meta.url)), 'db.json');
const allowedServiceTypes = new Set(['academic', 'hardware_lab', 'project_review', 'tech_support']);

async function readDb() {
  try { return JSON.parse(await readFile(DB_PATH, 'utf8')); }
  catch { return { requests: [] }; }
}
async function writeDb(db) {
  await writeFile(DB_PATH, JSON.stringify(db, null, 2) + '\n', 'utf8');
}
function send(res, status, payload) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Cache-Control': 'no-store',
  });
  res.end(JSON.stringify(payload));
}
async function readBody(req) {
  let raw = '';
  for await (const chunk of req) {
    raw += chunk;
    if (raw.length > 100_000) throw new Error('El cuerpo supera el tamaño permitido.');
  }
  return JSON.parse(raw || '{}');
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, {});
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  try {
    if (req.method === 'GET' && url.pathname === '/api/health') {
      return send(res, 200, { status: 'ok', service: 'USCO Ionic Forms API' });
    }
    if (req.method === 'GET' && url.pathname === '/api/requests') {
      const db = await readDb();
      return send(res, 200, db.requests);
    }
    if (req.method === 'POST' && url.pathname === '/api/requests') {
      const body = await readBody(req);
      const fullName = typeof body.fullName === 'string' ? body.fullName.trim() : '';
      if (!fullName || fullName.length > 120) return send(res, 400, { message: 'El nombre es obligatorio y debe tener máximo 120 caracteres.' });
      if (!allowedServiceTypes.has(body.serviceType)) return send(res, 400, { message: 'El tipo de servicio no es válido.' });
      if (typeof body.smsNotifications !== 'boolean' || body.acceptTerms !== true) {
        return send(res, 400, { message: 'Debe indicar las notificaciones y aceptar los términos.' });
      }
      const db = await readDb();
      const request = {
        id: db.requests.reduce((max, item) => Math.max(max, Number(item.id) || 0), 0) + 1,
        fullName,
        serviceType: body.serviceType,
        smsNotifications: body.smsNotifications,
        acceptTerms: true,
        createdAt: new Date().toISOString(),
      };
      db.requests.push(request);
      await writeDb(db);
      return send(res, 201, request);
    }
    return send(res, 404, { message: 'Ruta no encontrada.' });
  } catch (error) {
    const message = error instanceof SyntaxError ? 'JSON inválido.' : (error instanceof Error ? error.message : 'Error interno.');
    return send(res, 400, { message });
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`USCO Ionic Forms API escuchando en http://localhost:${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/api/health`);
});
