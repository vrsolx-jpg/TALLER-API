import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonCardContent,
  IonList,
  IonItem,
  IonInput,
  IonSelect,
  IonSelectOption,
  IonToggle,
  IonCheckbox,
  IonButton,
  IonButtons,
  IonIcon,
  IonBadge,
  IonModal,
  IonSpinner,
  IonLabel
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  phonePortraitOutline,
  createOutline,
  documentTextOutline,
  paperPlaneOutline,
  closeCircleOutline,
  refreshOutline
} from 'ionicons/icons';
import { BookingRequest, AVAILABLE_SERVICES, ServiceCategory, SavedBookingRequest } from '../models/booking-request.model';
import { FeedbackService } from '../services/feedback.service';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardSubtitle,
    IonCardContent,
    IonList,
    IonItem,
    IonInput,
    IonSelect,
    IonSelectOption,
    IonToggle,
    IonCheckbox,
    IonButton,
    IonButtons,
    IonIcon,
    IonBadge,
    IonModal,
    IonSpinner,
    IonLabel
  ]
})
export class HomePage implements OnInit {
  private readonly feedbackService = inject(FeedbackService);
  private readonly apiService = inject(ApiService);

  readonly services: ServiceCategory[] = AVAILABLE_SERVICES;

  formData: BookingRequest = {
    fullName: '',
    serviceType: '',
    smsNotifications: true,
    acceptTerms: false
  };

  isTermsModalOpen: boolean = false;
  isSubmitting = false;
  apiConnected = false;
  savedRequests: SavedBookingRequest[] = [];

  constructor() {
    addIcons({
      phonePortraitOutline,
      createOutline,
      documentTextOutline,
      paperPlaneOutline,
      closeCircleOutline,
      refreshOutline
    });
  }

  ngOnInit(): void {
    this.apiService.checkHealth().subscribe({
      next: () => this.apiConnected = true,
      error: () => this.apiConnected = false
    });
    this.loadRequests();
  }

  loadRequestsForRefresh(): void {
    this.loadRequests();
  }

  private loadRequests(): void {
    this.apiService.getRequests().subscribe({
      next: (data) => this.savedRequests = [...data].reverse(),
      error: () => this.apiConnected = false
    });
  }

  setTermsModalOpen(isOpen: boolean): void {
    this.isTermsModalOpen = isOpen;
  }


  async enviarSolicitud(): Promise<void> {
    const trimmedName = this.formData.fullName ? this.formData.fullName.trim() : '';

    if (!trimmedName || !this.formData.serviceType || !this.formData.acceptTerms) {
      await this.feedbackService.showToast(
        'Por favor complete los campos obligatorios (*)',
        'danger',
        3000
      );
      return;
    }

    this.isSubmitting = true;
    this.apiService.createRequest({ ...this.formData, fullName: trimmedName }).subscribe({
      next: async (savedRequest) => {
        this.isSubmitting = false;
        this.apiConnected = true;
        this.savedRequests = [savedRequest, ...this.savedRequests];
        const selectedService = this.services.find(s => s.id === savedRequest.serviceType);
        const serviceName = selectedService ? selectedService.name : savedRequest.serviceType;
        const smsStatusText = savedRequest.smsNotifications ? 'Habilitadas (Sí)' : 'Deshabilitadas (No)';
        await this.feedbackService.showAlert(
          '¡Solicitud guardada en la API!',
          'Universidad Surcolombiana',
          `<strong>Radicado:</strong> ${savedRequest.id}<br>
          <strong>Estudiante:</strong> ${savedRequest.fullName}<br>
          <strong>Servicio:</strong> ${serviceName}<br>
          <strong>Notificaciones SMS:</strong> ${smsStatusText}<br>
          <strong>Fecha:</strong> ${new Date(savedRequest.createdAt).toLocaleString('es-CO')}<br><br>
          <em>La solicitud fue almacenada por el backend.</em>`,
          'Aceptar'
        );
        this.formData = { fullName: '', serviceType: '', smsNotifications: true, acceptTerms: false };
      },
      error: async (err: { error?: { message?: string } }) => {
        this.isSubmitting = false;
        await this.feedbackService.showToast(
          err.error?.message || 'No fue posible conectar con la API. Verifica que el backend esté ejecutándose.',
          'danger',
          4500
        );
      }
    });
  }
}
