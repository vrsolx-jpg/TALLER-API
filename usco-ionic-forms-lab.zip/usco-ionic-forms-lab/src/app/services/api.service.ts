import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { BookingRequest, SavedBookingRequest } from '../models/booking-request.model';

/** Servicio centralizado para consumir la API REST del laboratorio. */
@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly http = inject(HttpClient);
  private readonly apiUrl = `${environment.apiUrl}/requests`;

  getRequests(): Observable<SavedBookingRequest[]> {
    return this.http.get<SavedBookingRequest[]>(this.apiUrl);
  }

  createRequest(data: BookingRequest): Observable<SavedBookingRequest> {
    return this.http.post<SavedBookingRequest>(this.apiUrl, data);
  }

  checkHealth(): Observable<{ status: string; service: string }> {
    return this.http.get<{ status: string; service: string }>(`${environment.apiUrl}/health`);
  }
}
