/**
 * URL base del backend. Para probar en un dispositivo físico, reemplaza
 * localhost por la IP local del computador que ejecuta `npm run api`.
 */
export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000/api',
};
